namespace CfSampleAppDotNetCore.Models
{
    public class Kitten
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
